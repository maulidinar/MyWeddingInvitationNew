<!DOCTYPE html>
<html>

<head>
    <title>Laporan Tamu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <style type="text/css">
        table tr td,
        table tr th {
            font-size: 9pt;
        }
    </style>
    <center>
        <h5>LAPORAN TAMU</h4>
        </h5>
    </center>

    <table class='table table-bordered'>
        <thead>
            <tr>
                <th>No</th>
                <th>QR</th>
                <th>Nama Tamu</th>
                <th>Email</th>
                <th>Undangan</th>
                <th>Tanggal</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            @php $i=1 @endphp
            @foreach($data as $key => $value)
            <tr>
                <td>{{ $i++}}</td>
                <td align="center">
                    <img id="myImg{{ $key }}" onerror="this.onerror=null;this.src='{{ asset('images/noimage.png') }}';" width="70"
                        src="{{ asset('/storage/qrcodes/' . 'QR-'.$value->qr_code.'.png') }}" alt="">
                    {{ $value->qr_code }}
                </td>
                <td class="text-left">
                    <a class="flex items-center items-center">
                        {{ $value->nama_tamu }}</a>
                </td>
                <td class="text-left">
                    <a class="flex items-center items-center">
                        {{ $value->email }}</a>
                </td>
                <td class="text-left">
                    <a class="flex items-center items-center">
                        {{ $value->nama_pria }} & {{ $value->nama_wanita }}</a>
                </td>
                <td class="text-left">
                    <a class="flex items-center items-center">
                        {{ $value->waktu }}</a>
                </td>
                <td class="table-report__action w-auto ">
                    @if ($value->kehadiran != NULL)
                    <div align='center' class="py-2 px-2 rounded-full text-xs bg-theme-9 text-white cursor-pointer font-medium"
                        style="width: 90px">
                        <i data-feather="check-circle"></i> Hadir
                    </div>
                    @else
                    <div align='center' class="py-2 px-2 rounded-full text-xs bg-theme-6 text-white cursor-pointer font-medium"
                        style="width: 90px">
                        <i data-feather="check-circle" style="font-size: 10px"></i> Belum Hadir
                    </div>
                    @endif
            
            
                </td>
            
            </tr>
            @endforeach
        </tbody>
    </table>

</body>

</html>